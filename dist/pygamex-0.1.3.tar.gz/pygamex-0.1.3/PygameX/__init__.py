#-----------------------------
#
# Author: k0cteJl
# Telegram: @k0cteJl
#
#-----------------------------
from .all_objects import *
from .game import *

pygame.font.init()

print(f"PygameX 0.1.3")