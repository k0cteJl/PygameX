#-----------------------------
#
# Author: k0cteJl
# Telegram: @k0cteJl
#
#-----------------------------

from .all_objects import *
from .game import *

version = "0.1.1"

print(f"PygameX {version}")