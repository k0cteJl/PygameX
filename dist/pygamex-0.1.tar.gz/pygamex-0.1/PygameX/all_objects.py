from .objects.Object import Object

from .objects.Rect import Rect
from .objects.Circle import Circle
from .objects.Line import Line