import pygame

class Object:

    """
    Main Object class
    """
    
    def render(self, screen):
        pass
